#include SRVR_WTHREADS_GLBLVAR_INIT
#include STCHMG_PLC_SRVR_GLBLVAR_INIT
#include SRVR1_GLBLVAR_INIT
#include SRVR2_GLBLVAR_INIT
#include SRVR3_GLBLVAR_INIT
#include SRVR4_GLBLVAR_INIT
#include SRVR5_GLBLVAR_INIT
#include SRVR6_GLBLVAR_INIT
#include SRVR7_GLBLVAR_INIT
#include SRVR8_GLBLVAR_INIT
#include SRVR9_GLBLVAR_INIT

pthread_t usr_param;
pthread_t bess_optmz;
unsigned int usr_ctrl_mode;
unsigned short int pl_besssp_flg = 0;
