#ifdef STCH_MG_ACTUAL
	#define SERVER3_IP "192.168.0.8"
#else  STCH_MG_HIL
	#define SERVER3_IP "192.168.0.69"
#endif

#ifdef STCH_MG_Actual
	#define SERVER3_MBPORT 503
#else  STCH_MG_HIL
	#define SERVER3_MBPORT 502
#endif

#define SERVER3_DBG_MSG FALSE //switch for modbus debug messages
#define SERVER3_NREAD_REGS 34 //
#define SERVER3_START_RADDR 384 //starting read register address

