// *************************** MODBUS READ Code for Server 2 - Modify as required *********************************************************************

//------ Thread waiting for server 3 read data to arrive -------------------
void* mbsrvr3_rwait_thread (void* args)
{
	int meter_poi_3p_plr;
	int meter_poi_3q_plr;
	int meter_poi_3s_plr;
	int meter_poi_pf_plr;
	int meter_poi_ia_plr;
	int meter_poi_ib_plr;
	int meter_poi_ic_plr;
	int meter_poi_in_plr;
	int meter_poi_vab_plr;
	int meter_poi_vbc_plr;
	int meter_poi_vca_plr;
	int meter_poi_freq_plr;

	float meter_poi_freq_flt;
	float meter_poi_ia_flt;
	float meter_poi_ib_flt;
	float meter_poi_ic_flt;
	float meter_poi_in_flt;
	float meter_poi_3p_flt;
	float meter_poi_3q_flt;
	float meter_poi_3s_flt;
	float meter_poi_pf_flt;
	float meter_poi_vab_flt;
	float meter_poi_vbc_flt;
	float meter_poi_vca_flt;

	int meter_poi_vs_plr;
	float meter_poi_vs_flt;

	int16_t meter_poi_3p_plr_16;


	srvr3_rdbk_waitloop:
	//waiting for server 3 readback data to arrive
	sem_wait(&srvr3_rdbk_sem);

	//***********************************************************
	//here you can map modbus read register data to fpga msi interface signals for this server

	//***********************************************************

#ifdef STCH_MG_ACTUAL
	//POI frequency reading from the meter going to PL should be scaled by x100. If not already scaled in the meter, scale it here
	meter_poi_freq_plr 	= 6000;

	meter_poi_ia_plr 	= 0;

	meter_poi_ib_plr 	= 0;

	meter_poi_ic_plr 	= 0;

	meter_poi_in_plr 	= 0;

	meter_poi_3p_plr_16 	= (*server3_rregs_ptr);
	meter_poi_3p_plr		= meter_poi_3p_plr_16; //converting 16bit into to 32bit int
	meter_poi_3p_plr    	= meter_poi_3p_plr*10; //scaling factor

	meter_poi_pf_plr 	= 100;

	meter_poi_3q_plr 	= 0;

	meter_poi_3s_plr 	= meter_poi_3p_plr;


	//POI voltage reading from the meter going to PL should be scaled by x100. If not already scaled in the meter, scale it here
	meter_poi_vab_plr 	= 48000;

	meter_poi_vbc_plr 	= 48000;

	meter_poi_vca_plr 	= 48000;

	meter_poi_vs_plr 	= 48000;
#else
	//POI frequency reading from the meter going to PL should be scaled by x100. If not already scaled in the meter, scale it here
	meter_poi_freq_flt 	= combineRegistersToFloat(server3_rregs_ptr);
	meter_poi_freq_flt  = (meter_poi_freq_flt*100);
	meter_poi_freq_plr  = meter_poi_freq_flt; //note that _plr  needs to be int, if its uint, float to int conversion will drop the sign

	meter_poi_ia_flt 	= combineRegistersToFloat(server3_rregs_ptr+2);
	meter_poi_ia_plr	= meter_poi_ia_flt;

	meter_poi_ib_flt 	= combineRegistersToFloat(server3_rregs_ptr+4);
	meter_poi_ib_plr	= meter_poi_ib_flt;

	meter_poi_ic_flt 	= combineRegistersToFloat(server3_rregs_ptr+6);
	meter_poi_ic_plr	= meter_poi_ic_flt;

	meter_poi_in_flt 	= combineRegistersToFloat(server3_rregs_ptr+8);
	meter_poi_in_plr	= meter_poi_in_flt;

	meter_poi_3p_flt 	= combineRegistersToFloat(server3_rregs_ptr+10);
	meter_poi_3p_flt	= meter_poi_3p_flt*1000;
	meter_poi_3p_plr    = meter_poi_3p_flt*(-1);//sign is flipped coming from PLC

	meter_poi_pf_flt 	= combineRegistersToFloat(server3_rregs_ptr+12);
	meter_poi_pf_flt    = meter_poi_pf_flt*100;
	meter_poi_pf_plr	= meter_poi_pf_flt;

	meter_poi_3q_flt 	= combineRegistersToFloat(server3_rregs_ptr+14);
	meter_poi_3q_flt	= meter_poi_3q_flt*1000;
	meter_poi_3q_plr    = meter_poi_3q_flt;

	meter_poi_3s_flt 	= combineRegistersToFloat(server3_rregs_ptr+16);
	meter_poi_3s_flt	= meter_poi_3s_flt*1000;
	meter_poi_3s_plr    = meter_poi_3s_flt;


	//POI voltage reading from the meter going to PL should be scaled by x100. If not already scaled in the meter, scale it here
	meter_poi_vab_flt 	= combineRegistersToFloat(server3_rregs_ptr+20);
	meter_poi_vab_flt   = meter_poi_vab_flt*100;
	meter_poi_vab_plr	= meter_poi_vab_flt;

	meter_poi_vbc_flt 	= combineRegistersToFloat(server3_rregs_ptr+24);
	meter_poi_vbc_flt   = meter_poi_vbc_flt*100;
	meter_poi_vbc_plr	= meter_poi_vbc_flt;

	meter_poi_vca_flt 	= combineRegistersToFloat(server3_rregs_ptr+28);
	meter_poi_vca_flt   = meter_poi_vca_flt*100;
	meter_poi_vca_plr	= meter_poi_vca_flt;

	meter_poi_vs_flt 	= combineRegistersToFloat(server3_rregs_ptr+32);
	meter_poi_vs_flt   = meter_poi_vs_flt*100;
	meter_poi_vs_plr	= meter_poi_vs_flt;

#endif

	//--------------- Writing Data to PS DDR --------------------------------------------

	  //POI Active Power
	  //printf ("Meter POI 3P %d \n",meter_poi_3p_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET] = meter_poi_3p_plr;

	  //POI Reactive Power
	  //printf ("Meter POI 3Q %d \n",meter_poi_3q_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+1] = meter_poi_3q_plr;

	  //POI Apparent Power
	  //printf ("Meter POI 3S %d \n",meter_poi_3s_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+2] = meter_poi_3s_plr;

	  //POI PF
	  //printf ("Meter POI PF %d \n",meter_poi_pf_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+3] = meter_poi_pf_plr;

	  //POI Phase A Current
	  //printf ("Meter POI Ia %d \n",meter_poi_ia_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+4] = meter_poi_ia_plr;

	  //POI Phase B Current
	  //printf ("Meter POI Ib %d \n",meter_poi_ib_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+5] = meter_poi_ib_plr;

	  //POI Phase C Current
	  //printf ("Meter POI Ic %d \n",meter_poi_ic_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+6] = meter_poi_ic_plr;

	  //POI Neutral Current
	  //printf ("Meter POI In %d \n",meter_poi_in_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+7] = meter_poi_in_plr;

	  //POI VAB
	  //printf ("Meter POI Vab %d \n",meter_poi_vab_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+8] = meter_poi_vab_plr;

	  //POI VBC
	  //printf ("Meter POI Vbc %d \n",meter_poi_vbc_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+9] = meter_poi_vbc_plr;

	  //POI VCA
	  //printf ("Meter POI Vca %d \n",meter_poi_vca_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+10] = meter_poi_vca_plr;

	  //POI Frequency
	  //printf ("Meter POI Freq %d \n",meter_poi_freq_plr);
	  vadd_psddr[SRVR3_READ_PSDDR_OFFSET+11] = meter_poi_freq_plr;


	//request CDMA transfer
	reacquire_srvr3_rmutex:
	pthread_mutex_lock(&mutex_cdma_trnsf);
	if (cdma_trnsf_chk==TRUE)
	{
		pthread_mutex_unlock(&mutex_cdma_trnsf);
		goto reacquire_srvr3_rmutex;
	}
	cdma_trnsf_chk = TRUE;

	//Requesting CDMA transfer
	cdma_src_addr = PSDDR_PBASE + (SRVR3_READ_PSDDR_OFFSET*0x4);
    cdma_dest_addr = BRAM_PBASE + (SRVR3_READ_BRAM_OFFSET*0x4);
    cdma_trnsf_length = 0x30; //32bit*12locations = 48bytes. Note Max space reserved is 32bit*40locations = 160bytes

	pthread_cond_signal(&cond_cdma_trnsf);
	pthread_mutex_unlock(&mutex_cdma_trnsf);

	//loop back to wait state.
	goto srvr3_rdbk_waitloop;

	return 0;
}

// ------------------ Server3 MODBUS polling thread -----------------------
void* mbsrvr3_thread (void* args)
{
	//Server 3 variable initialization
	int rc;

	ctx_srvr3 = modbus_new_tcp(SERVER3_IP, SERVER3_MBPORT);
	modbus_set_debug(ctx_srvr3, SERVER3_DBG_MSG);

server3_mb_connec:
	if (modbus_connect(ctx_srvr3) == -1) {
		printf("Modbus Server 3 Connection Failed - Retrying\n");
		goto server3_mb_connec;
	}

server3_mb_read:

	/*reading multiple registers values*/
	rc = modbus_read_input_registers(ctx_srvr3, SERVER3_START_RADDR, SERVER3_NREAD_REGS, server3_rregs_ptr);

	if (rc != SERVER3_NREAD_REGS)
	{
		printf("ERROR Reading Server 3 Registers - Re-establishing Connection \n");
		modbus_close(ctx_srvr3);
		goto server3_mb_connec;
	}

	//sending signal to a waiting thread that read data has arrived
	sem_post(&srvr3_rdbk_sem);

	goto server3_mb_read; //continuous read

	return 0;
}
