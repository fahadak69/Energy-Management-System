#define SERVER8_IP "192.168.1.2000"
#define SERVER8_MBPORT 502
#define SERVER8_DBG_MSG FALSE //switch for modbus debug messages
#define SERVER8_NREAD_REGS 24//32 //assuming 32 read registers for server 2.This can be any number
#define SERVER8_START_RADDR 0 //starting read register address

