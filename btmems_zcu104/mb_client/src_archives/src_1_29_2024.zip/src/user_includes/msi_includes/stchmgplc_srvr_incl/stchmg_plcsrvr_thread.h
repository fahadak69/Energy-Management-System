// *************************** MODBUS READ AND WRITE Code for STCH MG PLC Server *********************************************************************
//Note 1: For real STCH MG, tesla doesnt allow polling by multiple clients and as such readback data for bess will come via PLC enbala interface

//Note 2: Necessary condition for two reasons, 1) to ensure bess_p_plw_offset doesnt contain garbage value or value from a previous
//control mode (as present in vadd_psddr memory location) 2) everytime a new dispatch setpoint comes in, we dont want to throw away
//the offset ane hence the flag stays asserted as long as the mode is 3 and is cleared if mode is not 3

// ------------------ STCH MG PLC Server Enbala Interface Heartbeat thread -----------------------
void* stchmgplc_hb_wthread (void* args)
{
	int plc_mbreg_wchk = 0;
	uint16_t plc_hb_regval = 2+4+32; //bit 1 Tesla En, bit 3 PV En, bit 5 is heartbeat toogle
	int rc[3];

    //********Creating context for PLC Modbus Server (Prosoft Card)
	ctx_plc = modbus_new_tcp(STCHMGPLC_SRVR_IP, STCHMGPLC_SRVR_MBPORT);
	modbus_set_debug(ctx_plc, STCHMGPLC_SRVR_DBG_MSG);

plc_mb_connec:
	if (modbus_connect(ctx_plc) == -1) {
		printf("PLC Modbus Server Connection Failed - Retrying\n");
		goto plc_mb_connec;
	}

//Heartbeat write to PLC Enbala Interface

stchmgplc_hb:
	if (plc_hb_regval==38)
		plc_hb_regval 	= 6; //toggling heart bit 5, keeping tesla and PV enable (ideally you should read back the value of this register first and only toggle bit 5 keeping other bits same)
	else
		plc_hb_regval 	= 38;


	if (stchmgplc_wsig!=0)
		sem_wait(&stchmgplc_w_sem);


	pthread_mutex_lock(&stchmgplc_w);
	   plc_mbreg_wchk = modbus_write_register(ctx_plc, 855, plc_hb_regval);

#ifdef STCH_MG_ACTUAL
	   rc[0] = modbus_read_registers(ctx_plc, 6117, 9, server1_rregs_ptr);//Note 1
	   rc[1] = modbus_read_registers(ctx_plc, 6088, 1, server3_rregs_ptr);
	   //rc[2] = modbus_read_registers(ctx_plc, 6126, 6, server2_rregs_ptr);
#endif

	pthread_mutex_unlock(&stchmgplc_w);

#ifdef STCH_MG_ACTUAL
	if (rc[0] != 9)
	{
		printf("ERROR reading Tesla Data from PLC (%d) \n",rc[0]);
		modbus_close(ctx_plc);
		goto plc_mb_connec;
	}
	//sending signal to a waiting thread that read data has arrived
	sem_post(&srvr1_rdbk_sem);
	if (rc[1] != 1)
	{
		printf("ERROR reading POI Meter Data from PLC (%d) \n",rc[1]);
		modbus_close(ctx_plc);
		goto plc_mb_connec;
	}
	//sending signal to a waiting thread that read data has arrived
	sem_post(&srvr3_rdbk_sem);

/*	if (rc[2] != 6)
	{
		printf("ERROR reading PV Data from PLC (%d) \n",rc[2]);
		modbus_close(ctx_plc);
		goto plc_mb_connec;
	}
	//sending signal to a waiting thread that read data has arrived
	sem_post(&srvr2_rdbk_sem);*/
#endif

	if (plc_mbreg_wchk == (-1))
	{
		printf("ERROR writing PLC heartbeat register (%d) \n", plc_mbreg_wchk);
		modbus_close(ctx_plc);
		goto plc_mb_connec;
	}

	goto stchmgplc_hb; //continuous heartbeat toggle

	return 0;
}

// ------------------ STCH MG PLC Server Enbala Interface Tesla P Setpoint Command thread -----------------------

void* stchmgplc_teslaP_wthread (void* args)
{
	int stchmgplc_teslap_mbreg_wchk = 0;
	int16_t stchmgplc_teslaP_regval;
	int bess_p_plw = 0;
	int bess_p_plw_opt = 0;
	int bess_p_plw_offset = 0;
	float bess_p_flt = 0;


stchmgplc_teslaP_loop:
	sem_wait(&stchmgplc_tesla_psem);

	pthread_mutex_lock(&stchmgplc_wsig_lck);
	stchmgplc_wsig++;
	pthread_mutex_unlock(&stchmgplc_wsig_lck);

	//BESS P command from PL
	if (usr_ctrl_mode==3) //BESS Dispatch Optimization
	{
		bess_p_plw_opt 		= bess_opt_p;
		bess_p_flt			= (bess_p_plw_opt*10); //Changing to kW with x10 scaling
		bess_p_plw			= bess_p_flt;

		if (pl_besssp_flg>0)//Note 2
		{
			bess_p_plw_offset 	= vadd_psddr[WCMD_PSDDR_OFFSET+1];
			bess_p_flt			= (bess_p_plw_offset/100); //Changing to kW with x10 scaling (10/1000)
			bess_p_plw_offset    = bess_p_flt;
			bess_p_plw			= bess_p_plw + bess_p_plw_offset;
			pl_besssp_flg       = 0;
		}

		//printf ("Optimization Dispatch %d\n",bess_p_plw);
	}
	else
	{
		bess_p_plw 			= vadd_psddr[WCMD_PSDDR_OFFSET+1];
		bess_p_flt			= (bess_p_plw/100); //Changing to kW with x10 scaling (10/1000)
		bess_p_plw			= bess_p_flt;
		//printf ("LF_PeakShav Dispatch %d\n",bess_p_plw);
	}

	//*******************
	//here you can map commands received to specific MODBUS write registers for the device
	stchmgplc_teslaP_regval = bess_p_plw;
	//**********************

	pthread_mutex_lock(&stchmgplc_w);
	stchmgplc_teslap_mbreg_wchk = modbus_write_register(ctx_plc, 852, stchmgplc_teslaP_regval);
	pthread_mutex_unlock(&stchmgplc_w);

	pthread_mutex_lock(&stchmgplc_wsig_lck);
	stchmgplc_wsig--;
	pthread_mutex_unlock(&stchmgplc_wsig_lck);

	if (stchmgplc_wsig==0)
		sem_post(&stchmgplc_w_sem);

    if (stchmgplc_teslap_mbreg_wchk == (-1))
    	printf("ERROR writing STCH MG PLC Tesla P Setpoint (%d)\n", stchmgplc_teslap_mbreg_wchk);

	goto stchmgplc_teslaP_loop;
	return 0;

}

// ------------------ STCH MG PLC Server Enbala Interface PV P Setpoint Command thread -----------------------

void* stchmgplc_pvP_wthread (void* args)

{
	int stchmgplc_pvp_mbreg_wchk = 0;
	int16_t stchmgplc_pvP_regval;
	int pv_p_plw = 0;
	float pv_p_flt = 0;

stchmgplc_pvP_loop:
	sem_wait(&stchmgplc_pv_psem);

	pthread_mutex_lock(&stchmgplc_wsig_lck);
	stchmgplc_wsig++;
	pthread_mutex_unlock(&stchmgplc_wsig_lck);

	//PV P command from PL
	pv_p_plw 			= vadd_psddr[WCMD_PSDDR_OFFSET+6];
	pv_p_flt			= (pv_p_plw/100); //Changing to kW with x10 scaling (10/1000)
	pv_p_plw			= pv_p_flt;


	//**************************
	//***here you can map commands received to specific MODBUS write registers for the device***
	stchmgplc_pvP_regval = pv_p_plw;
	//****************************

	pthread_mutex_lock(&stchmgplc_w);
	stchmgplc_pvp_mbreg_wchk = modbus_write_register(ctx_plc, 851, stchmgplc_pvP_regval);
	pthread_mutex_unlock(&stchmgplc_w);

	pthread_mutex_lock(&stchmgplc_wsig_lck);
	stchmgplc_wsig--;
	pthread_mutex_unlock(&stchmgplc_wsig_lck);

	if (stchmgplc_wsig==0)
		sem_post(&stchmgplc_w_sem);

    if (stchmgplc_pvp_mbreg_wchk == (-1))
    	printf("ERROR writing STCH MG PLC PV P Setpoint (%d)\n", stchmgplc_pvp_mbreg_wchk);

	goto stchmgplc_pvP_loop;
	return 0;
}

