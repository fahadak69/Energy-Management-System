#ifdef STCH_MG_ACTUAL
#define STCHMGPLC_SRVR_IP "192.168.0.12"
#else  STCH_MG_HIL
#define STCHMGPLC_SRVR_IP "192.168.0.24"
#endif


#define STCHMGPLC_SRVR_MBPORT 502
#define STCHMGPLC_SRVR_DBG_MSG FALSE //switch for modbus debug messages
