pthread_t mbsrvr_w;

uint64_t mbsrvr_wcmd_stat; //used to indicate which command was issue by PL. Refer to verilog for mapping of these bits

unsigned int  usr_bess_wh_soc100_pl; //BESS max energy at 100% SoC as input by user
