#define SERVER4_IP "192.168.1.2000"
#define SERVER4_MBPORT 502
#define SERVER4_DBG_MSG FALSE //switch for modbus debug messages
#define SERVER4_NREAD_REGS 2//32 //assuming 32 read registers for server 1.This can be any number
#define SERVER4_START_RADDR 10//1 //starting read register address

